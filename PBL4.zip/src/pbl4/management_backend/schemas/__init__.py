"""Backend API schemas (Pydantic models for request/response)."""
